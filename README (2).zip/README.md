# HOUSE PRICE PREDICTION

Algorithm : Linear Regression

Libraries Used:
- Scikit-learn
- Pandas
